package com.V3.loginpage;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class v3homepage {

		public v3homepage(WebDriver driver) {
			PageFactory.initElements(driver, this);
		}

		// Username field
		@FindBy(xpath = "//span[text()='Projects']")
		private WebElement projectBtn;

		public WebElement getProjectBtn() {
			return projectBtn;
		}

		@FindBy(xpath = "//a[text()='Project Details']")
		private WebElement projectDetailsBtn;

		public WebElement getProjectDetailsBtn() {
			return projectDetailsBtn;
		}

		@FindBy(xpath = "//i[@class='mdi mdi-plus']")
		private WebElement addProjectBtn;

		public WebElement getAddProjectBtn() {
			return addProjectBtn;
		}

		@FindBy(xpath = "//select[@formcontrolname='cloudType']")
		private WebElement selectDrpDwnCloudType;

		public WebElement getCloudDrpDwn() {
			return selectDrpDwnCloudType;
		}

		@FindBy(xpath = "//select[@formcontrolname='licenseType']")
		private WebElement selectDrpDwnLicenceType;

		public WebElement getLicenceTypeDrpDwn() {
			return selectDrpDwnLicenceType;
		}

		@FindBy(xpath = "//select[@formcontrolname='category']")
		private WebElement selectDrpDwnCategoryType;

		public WebElement getCategoryTypeDrpDwn() {
			return selectDrpDwnCategoryType;
		}	
		@FindBy(xpath = "//span[text() = 'Assessment']")
		private WebElement selectAssessment;

		public WebElement getAssessment() {
			return selectAssessment;
		}	
		//a[@class='nav-link active']
		@FindBy(xpath =  "//a[text()='Code Extraction']")
		private WebElement selectCodeextraction;

		public WebElement getCodeextraction() {
			return selectCodeextraction;
		}	
		//select[@formcontrolname='runNumber']"
		@FindBy(xpath =  "//select[@formcontrolname='runNumber']")
		private WebElement selectRunNo;

		public WebElement getRunNo() {
			return selectRunNo;
		}	
		//select[@formcontrolname='connectionType']
				@FindBy(xpath =  "//select[@formcontrolname='connectionType']")
				private WebElement ConnectionName;

				public WebElement GetConnectionName() {
					return ConnectionName;
				}	
				//select[@formcontrolname='operation']
				@FindBy(xpath =  "//select[@formcontrolname='operation']")
				private WebElement Operationdrpdn;

				public WebElement getOperationdrpdn() {
					return Operationdrpdn;
				}
							//span[text()='Select Schema Name']
				@FindBy(xpath =  "//span[text()='Select Schema Name']")
				private WebElement selectschemaname;

				public WebElement getselectschemaname() {
					return selectschemaname;
				}	
				//span[text()='Select Schema Name']
				@FindBy(xpath =  "//div[text()='ALL']")
				private WebElement selectschemaname1;

				public WebElement getselectschemanamedrpdwn() {
					return selectschemaname1;
				}
				
				//div[@class = 'col-md-9']
				@FindBy(xpath =  "//div[@class = 'col-md-9']")
				private WebElement Clickanywhere;

				public WebElement clickanywherebtn() {
					return Clickanywhere;
				}
				
				//i[@class='mdi mdi-check']
				@FindBy(xpath =  "//div[@class = 'col-md-3']//button")
				private WebElement Checkdetails;

				public WebElement clickcheckdetailsbtn() {
					return Checkdetails;
				}
							
				//button[@class='btn btn-outline-primary btn-icon-text w-100 py-2']
				@FindBy(xpath =  "//div[@class = 'col-md-12 text-right mt-3']//button")
				private WebElement executedetails;

				public WebElement clickexecutedetailsbtn() {
					return executedetails;
				}
				//a[@class='card-link collapsed'])[1]
				@FindBy(xpath =  "//a[@href = '#Description']")
						private WebElement codeextractionreports;

						public WebElement clickcodeextractionreports() {
					
							return codeextractionreports;
				}
						//select[@class='form-control ml-0'])[1]
								@FindBy(xpath =  "(//form[@class='form table-form ng-untouched ng-pristine ng-valid']//select)[1]")
								private WebElement runm12;

								public WebElement clickrunnm1() {
							
									return runm12;
						}
				//a[text()='Assessment']
				@FindBy(xpath =  "//a[text()='Assessment']")
				private WebElement Assessment;

				public WebElement clickAssessment() {
					
				return Assessment;
				}
						
						//select[@formcontrolname='runNumber']
				@FindBy(xpath =  "//select[@formcontrolname = 'runNumber']")
				private WebElement Runnmb1;

				public WebElement clickRunnmb1() {
				
					return Runnmb1;
				}
				//select[@formcontrolname='connectionType']
				@FindBy(xpath =  "//select[@formcontrolname='connectionType']")
				private WebElement connectionname1;

				public WebElement clickconnectionname1() {
				
					return connectionname1;
				}
					
				@FindBy(xpath =  "//select[@formcontrolname='operation']")
				private WebElement operation;

				public WebElement clickoperation() {
				
					return operation;
				}
				
				//span[text() = 'Select Schema Name']
				@FindBy(xpath =  "//span[text() = 'Select Schema Name']")
				private WebElement schemaName;

				public WebElement clickschemaName() {
				
					return schemaName;
				
		}
				
				//div[text() = 'ALL']
				@FindBy(xpath =  "//div[text()='Hrpay']")
				private WebElement schemaName1;

				public WebElement clickschemaName1() {
				
					return schemaName1;
				}
				//div[@class='col-md-9']
				@FindBy(xpath =  "//div[@class='col-md-9']")
				private WebElement Blankspace;

				public WebElement clickonBlankSpace() {
				
					return Blankspace;
				}
				//button[@class='btn btn-outline-primary btn-icon-text w-100 py-2']
				@FindBy(xpath =  "//button[@class='btn btn-outline-primary btn-icon-text w-100 py-2']")
				private WebElement checkdetails;

				public WebElement clickonCheckDetailsButton() {
				
					return Checkdetails;
				}
				//button[@class='btn btn-outline-primary btn-repo mr-1']
				@FindBy(xpath =  "//button[@class='btn btn-outline-primary btn-repo mr-1']")
				private WebElement executebtn;

				public WebElement clickonexecutebtn() {
				
					return executebtn;
				}
				//span[@class='ml-3 c-p pt-2'])[1]
				//h3//i[@class='fa fa-refresh ng-star-inserted']
						//button[@class='btn btn-outline-primary btn-repo mr-1']
						@FindBy(xpath =  "(//span[@class='ml-3 c-p pt-2'])[1]")
						private WebElement assessmentstatusbtn;

						public WebElement clickassessmentstatusbtn() {
						
							return assessmentstatusbtn;
						}
						//tr[@class='ng-star-inserted'])[20]
								@FindBy(xpath =  "//table//tr[2]")
								private WebElement blankspace;

								public WebElement clickblankspace() {
								
									return blankspace;
								}
						//select[@class='form-control ml-0'])[1]
								@FindBy(xpath =  "//i[@class='mdi mdi-file-document']")
								private WebElement assessmentreports;

								public WebElement clickassessmentreports() {
								
									return assessmentreports;
								}
								//input[@class='ng-untouched ng-pristine ng-valid'])[1]
										@FindBy(xpath =  "//input[@placeholder='Search Status']")
										private WebElement searchstatus;

										public WebElement entersearchstatus() {
										
											return searchstatus;
										}
								
		
								//select[@class='form-control ml-0'])[2]
								@FindBy(xpath =  "(//select[@class='form-control ml-0'])[2]")
								private WebElement assessmentreportsrunno;

								public WebElement clickassessmentreportsrunno() {
								
									return assessmentreportsrunno;
								}
								//select[@class='form-control'])[3]
								@FindBy(xpath =  "(//select[@class='form-control'])[3]")
								private WebElement selecthrs;

								public WebElement clickselecthrs() {
								
									return selecthrs;
								}
								//input[@placeholder='Search Reports']
								@FindBy(xpath =  "//input[@placeholder='Search Reports']")
								private WebElement searchreports;

								public WebElement entersearchreports() {
								
									return searchreports;
								}
								//a[@class='card-link collapsed'])[2]
								@FindBy(xpath =  "//i[@class='fas fa-users-cog']")
								private WebElement pageactivitylog;

								public WebElement clickpageactivitylog() {
								
									return pageactivitylog;
								}
								//select[@class='form-control ml-0'])[2]
								@FindBy(xpath =  "(//select[@class='form-control ml-0'])[3]")
								private WebElement pagerunno;

								public WebElement clickpagerunno() {
								
									return pagerunno;
								}
								//input[@class='ng-untouched ng-pristine ng-valid'])[3]
								@FindBy(xpath =  "(//input[@class='ng-untouched ng-pristine ng-valid'])[3]")
								private WebElement pagesearch;

								public WebElement clickpagesearch() {
								
									return pagesearch;
								}
								@FindBy(xpath =  "//span[text()=' Copyright ©2024 Quadrant Technologies ']")
								private WebElement footerpage;

								public WebElement clickfooterpage() {
								
									return footerpage;
								}
								//span[text()='Code Migration']
								@FindBy(xpath =  "//span[text()='Code Migration']")
								private WebElement codemigr;

								public WebElement clickcodemigr() {
								
									return codemigr;
								}
								//a[@class='nav-link active']
								@FindBy(xpath =  "//a[text()='Validation ']")
								private WebElement validation;

								public WebElement clickvalidation() {
								
									return validation;
								}
								//select[@class='form-control ml-0'])[1]
								@FindBy(xpath =  "//select[@formcontrolname='runNumber']")
								private WebElement validationrunno;

								public WebElement clickvalidationrunno() {
								
									return validationrunno;
								}
								
								//select[@formcontrolname='connectionType']
								@FindBy(xpath =  "//select[@formcontrolname='connectionType']")
								private WebElement validationconnectionname;

								public WebElement clickvalidationconnectionname() {
								
									return validationconnectionname;
								}
								
								//select[@formcontrolname='targetConnection']
								@FindBy(xpath =  "//select[@formcontrolname='targetConnection']")
								private WebElement validationtargetname;

								public WebElement clickvalidationvalidationtargetnamename() {
								
									return validationtargetname;
								}
								//select[@formcontrolname='operation']
								@FindBy(xpath =  "//select[@formcontrolname='operation']")
								private WebElement validationoperationname;

								public WebElement clickvalidationoperationname() {
								
									return validationoperationname;
								}
								//span[@class='dropdown-btn']
								@FindBy(xpath =  "//span[@class='dropdown-btn']")
								private WebElement validationschemaname;

								public WebElement clickvvalidationschemaname() {
								
									return validationschemaname;
								}
								@FindBy(xpath =  "//div[text()='Hrpay']")
								private WebElement validation1schemaname;

								public WebElement clickvvalidation1schemaname() {
								
									return validation1schemaname;
								}
								//button[@class='btn btn-outline-primary btn-icon-text w-100 py-2']
								@FindBy(xpath =  "//button[@class='btn btn-outline-primary btn-icon-text w-100 py-2']")
								private WebElement validationcheckdetails;

								public WebElement clickvalidationcheckdetails() {
								
									return validationcheckdetails;
								}
								//button[@class='btn btn-outline-primary btn-repo mr-1']
								@FindBy(xpath =  "//button[@class='btn btn-outline-primary btn-repo mr-1']")
								private WebElement validationexecutedetails;

								public WebElement clickvalidationexecutedetails() {
								
									return validationexecutedetails;
								}
								//i[@class='fa fa-refresh ng-star-inserted'])[1]
								@FindBy(xpath =  "/html/body/app-root/app-index/div/div/app-validation/div/div[2]/div/div/div/div[2]/h3/span")
								private WebElement validationstatus;

								public WebElement clickvalidationstatusrefreshbtn() {
								
									return validationstatus;
								}
								//span[@class='ml-3 c-p pt-2'])[1]
								//i[@class='mdi mdi-file-document']
								@FindBy(xpath =  "//i[@class='mdi mdi-file-document']")
								private WebElement validationreports;

								public WebElement clickvalidationreports() {
								
									return validationreports;
								}
								//select[@class='form-control ml-0'])[2]
										@FindBy(xpath =  "(//select[@class='form-control ml-0'])[2]")
										private WebElement validationreportsrunno;

										public WebElement clickvalidationreportsrunno() {
										
											return validationreportsrunno;
										}
										@FindBy(xpath =  "(//select[@class='form-control'])[3]")
										private WebElement validationreportshrs;

										public WebElement clickvalidationreportshrs() {
										
											return validationreportshrs;
										}
										//select[@class='form-control'])[3]
								//ul[@aria-label='Pagination'])[1]	
										@FindBy(xpath =  "(//ul[@aria-label='Pagination'])[1]")
										private WebElement validationblankspace;

										public WebElement clickvalidationblankspace() {
										
											return validationblankspace;
										}
										//i[@class='fas fa-users-cog']
										
										@FindBy(xpath =  "//i[@class='fas fa-users-cog']")
										private WebElement validationpageactivitylog;

										public WebElement clickvalidationpageactivitylog() {
										
											return validationpageactivitylog;
										}
										//table//tr[@class='ng-star-inserted'])[13]
										@FindBy(xpath =  "(//table//tr[@class='ng-star-inserted'])[13]")
										private WebElement validationpageactivitylblank;

										public WebElement clickvalidationpageactivitylblank() {
										
											return validationpageactivitylblank;
										}
										//select[@class='form-control ml-0'])[3]			
										@FindBy(xpath =  "(//select[@class='form-control ml-0'])[3]")
										private WebElement validationpageactivitylrunno;

										public WebElement clickvalidationpageactivitylrunno() {
										
											return validationpageactivitylrunno;
										}
										//h3[@class='card-title'])[1]
										@FindBy(xpath =  "(//h3[@class='card-title'])[1]")
										private WebElement blnk;

										public WebElement clickblnk() {
										
											return blnk;
										}
										
}