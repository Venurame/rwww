package com.V3.loginpage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class V3Loginpage {

		public V3Loginpage(WebDriver driver) {
			PageFactory.initElements(driver, this);
		}

		// Username field
		@FindBy(xpath = "//input[@placeholder='Email']")
		private WebElement usernameEle;

		public WebElement getUsernameEle() {
			return usernameEle;
		}
		// password field

		@FindBy(xpath = "//input[@placeholder='Key']")
		private WebElement KeyEle;

		public WebElement getKeyEle() {
			return KeyEle;
		}

		// submit button
		// button[@class='btn btn-sign btn-bs']
		@FindBy(xpath = "//button[@class='btn btn-sign btn-bs']")
		private WebElement SignInBtn;

		public WebElement getSignInBtn() {
			return SignInBtn;
		}
	


}
