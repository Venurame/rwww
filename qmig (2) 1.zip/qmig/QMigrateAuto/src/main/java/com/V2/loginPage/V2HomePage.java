package com.V2.loginPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class V2HomePage {

	public V2HomePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	// Username field
	@FindBy(xpath = "//span[text()='Projects']")
	private WebElement projectBtn;

	public WebElement getProjectBtn() {
		return projectBtn;
	}

	@FindBy(xpath = "//a[text()='Project Details']")
	private WebElement projectDetailsBtn;

	public WebElement getProjectDetailsBtn() {
		return projectDetailsBtn;
	}

	@FindBy(xpath = "//i[@class='mdi mdi-plus']")
	private WebElement addProjectBtn;

	public WebElement getAddProjectBtn() {
		return addProjectBtn;
	}

	@FindBy(xpath = "//select[@formcontrolname='cloudType']")
	private WebElement selectDrpDwnCloudType;

	public WebElement getCloudDrpDwn() {
		return selectDrpDwnCloudType;
	}

	@FindBy(xpath = "//select[@formcontrolname='licenseType']")
	private WebElement selectDrpDwnLicenceType;

	public WebElement getLicenceTypeDrpDwn() {
		return selectDrpDwnLicenceType;
	}

	@FindBy(xpath = "//select[@formcontrolname='category']")
	private WebElement selectDrpDwnCategoryType;

	public WebElement getCategoryTypeDrpDwn() {
		return selectDrpDwnCategoryType;
	}

	@FindBy(xpath = "//select[@formcontrolname='projectType']")
	private WebElement selectDrpDwnProjectType;

	public WebElement getProjectTypeDrpDwn() {
		return selectDrpDwnProjectType;
	}
	
	
	
	@FindBy(xpath = "//select[@formcontrolname='clientId']")
	private WebElement selectDrpDwnClient;

	public WebElement getClientDrpDwn() {
		return selectDrpDwnClient;
	}
	
	@FindBy(xpath = "//input[@placeholder='Project Name']")
	private WebElement projectNameTxt;

	public WebElement getProjectTextField() {
		return projectNameTxt;
	}
	
	
	@FindBy(xpath = "//button[text()='Add ']")
	private WebElement addSubmitBtn;

	public WebElement getAddSubmitBtn() {
		return addSubmitBtn;
	}
	
	//*[@id="ui-basic2"]/ul/li[5]/a
	@FindBy(xpath = "//*[@id=\"ui-basic2\"]/ul/li[5]/a")
	private WebElement licencekeyBtn;

	public WebElement getlicencekeyBtnBtn() {
		return licencekeyBtn;
	}

}
