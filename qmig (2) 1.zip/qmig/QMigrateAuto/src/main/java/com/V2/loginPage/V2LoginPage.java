package com.V2.loginPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class V2LoginPage {

	public V2LoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	// Username field
	@FindBy(xpath = "//input[@placeholder='Email']")
	private WebElement usernameEle;

	public WebElement getUsernameEle() {
		return usernameEle;
	}
	// password field

	@FindBy(xpath = "//input[@placeholder='Password']")
	private WebElement passwordEle;

	public WebElement getPasswordEle() {
		return passwordEle;
	}

	// submit button
	// button[@class='btn btn-sign btn-bs']
	@FindBy(xpath = "//button[@class='btn btn-sign btn-bs']")
	private WebElement SignInBtn;

	public WebElement getSignInBtn() {
		return SignInBtn;
	}
}
