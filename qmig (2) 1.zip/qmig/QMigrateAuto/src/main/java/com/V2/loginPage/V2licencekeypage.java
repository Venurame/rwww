package com.V2.loginPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class V2licencekeypage {
	
	public V2licencekeypage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	// Username field
	@FindBy(xpath = "//select[@aria-label]")
	private WebElement projectsdropdown;

	public WebElement getprojectsdropdown() {
		return projectsdropdown;
	}

	@FindBy(xpath = "//select[@class = 'form-control']")
	private WebElement projectdrpdwn;
	public WebElement getprojectdrpdwn() {
		projectdrpdwn.click();
		return projectdrpdwn;
	}
	

}