package com.genericsUtils;

public interface IpathConstant {

	String PROPERTY_FILEPATH="./Data/CommonData.properties";
	String JSONFILEPATH = "./Data/CommonData.json";
	String EXCELPATH = "./Data/projecttestcase.xls";
	
}
