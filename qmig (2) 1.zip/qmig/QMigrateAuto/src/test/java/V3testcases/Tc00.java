package V3testcases;

import org.testng.annotations.Test;

import com.V3.loginpage.v3homepage;
import com.genericsUtils.V3BaseClass;

public class Tc00 extends V3BaseClass{
@Test
public void tc1() throws Throwable {

	Thread.sleep(3000);

	v3homepage v3hmpg2 = new v3homepage(driver);
	
	v3hmpg2.getProjectBtn().click();
	v3hmpg2.getProjectDetailsBtn().click();
	v3hmpg2.getAddProjectBtn().click();
	Thread.sleep(3000);
}
}
