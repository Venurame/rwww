package V3testcases;

import org.testng.annotations.Test;

import com.V3.loginpage.v3homepage;
import com.genericsUtils.V3BaseClass;

public class tc026 extends V3BaseClass {
	@Test
	public void tc3() throws Throwable {

		v3homepage v3hmpg2 = new v3homepage(driver);
		v3hmpg2.getAssessment().click();
		Thread.sleep(2000);
		v3hmpg2.getCodeextraction().click();
		Thread.sleep(2000);
		wLib.SelectOption(v3hmpg2.getRunNo(), 1);
		Thread.sleep(2000);
		wLib.SelectOption(v3hmpg2.GetConnectionName(), 1);
		Thread.sleep(2000);
		wLib.SelectOption(v3hmpg2.getOperationdrpdn(), 1);
		v3hmpg2.getselectschemaname().click();
		v3hmpg2.getselectschemanamedrpdwn().click();
		Thread.sleep(5000);
		v3hmpg2.clickanywherebtn().click();
		Thread.sleep(2000);
		v3hmpg2.clickcheckdetailsbtn().click();
		Thread.sleep(5000);
		v3hmpg2.clickexecutedetailsbtn().click();
		Thread.sleep(5000);
		v3hmpg2.clickcodeextractionreports().click();
		System.out.println("Code Extraction button clicked successfully");
		Thread.sleep(5000);
		wLib.SelectOption(v3hmpg2.clickrunnm1(), 1);
		
	}

}
