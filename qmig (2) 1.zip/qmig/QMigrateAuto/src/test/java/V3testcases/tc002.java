package V3testcases;

import org.testng.annotations.Test;

import com.V3.loginpage.v3homepage;
import com.genericsUtils.V3BaseClass;

public class tc002 extends V3BaseClass{
@Test
	public void tc2() throws Throwable {

		Thread.sleep(3000);

		v3homepage v3hmpg2 = new v3homepage(driver);
		v3hmpg2.getAssessment().click();
		
		v3hmpg2.getCodeextraction().click();
		wLib.SelectOption(v3hmpg2.getRunNo(), 1);
		wLib.SelectOption(v3hmpg2.GetConnectionName(), 1);
		Thread.sleep(5000);
	}
}
