package V3testcases;

import org.testng.annotations.Test;

import com.V3.loginpage.v3homepage;
import com.genericsUtils.V3BaseClass;

public class TC001 extends V3BaseClass{
	@Test
	public void tc1() throws Throwable {

		Thread.sleep(3000);

		v3homepage v3hmpg2 = new v3homepage(driver);
		Thread.sleep(1000);
		v3hmpg2.getAssessment().click();
		
		v3hmpg2.getCodeextraction().click();
		Thread.sleep(1000);
		wLib.SelectOption(v3hmpg2.getRunNo(), 1);
		Thread.sleep(5000);
	}

}

