package V3testcases;

import org.testng.annotations.Test;

import com.V3.loginpage.v3homepage;
import com.genericsUtils.V3BaseClass;

public class tc029 extends V3BaseClass{
@Test
	public void tc3() throws Throwable {

		v3homepage v3hmpg2 = new v3homepage(driver);
		v3hmpg2.getAssessment().click();
		Thread.sleep(2000);
		v3hmpg2.clickAssessment().click();
		Thread.sleep(3000);
		v3hmpg2.clickRunnmb1().click();
		Thread.sleep(3000);
		wLib.SelectOption(v3hmpg2.clickRunnmb1(), 2);
		v3hmpg2.clickconnectionname1().click();
		Thread.sleep(3000);
		wLib.SelectOption(v3hmpg2.clickconnectionname1(), 2);
		Thread.sleep(3000);
		
		
	}
}
