package testScripts;

import org.testng.annotations.Test;

import com.V2.loginPage.V2HomePage;
import com.V2.loginPage.V2licencekeypage;
import com.genericsUtils.BaseClass;

public class Tc1 extends BaseClass {

	@Test
	public void tc() throws Throwable {

		Thread.sleep(3000);

		V2HomePage v2hmpg = new V2HomePage(driver);
		
		v2hmpg.getProjectBtn().click();
		v2hmpg.getProjectDetailsBtn().click();
		v2hmpg.getAddProjectBtn().click();
		Thread.sleep(2000);
		
		V2licencekeypage v2lcnpg = new V2licencekeypage(driver);
		
		wLib.SelectOption(v2hmpg.getCloudDrpDwn(), 2);
		wLib.SelectOption(v2hmpg.getLicenceTypeDrpDwn(), 3);
		wLib.SelectOption(v2hmpg.getCategoryTypeDrpDwn(), 2);
		Thread.sleep(2000);
		wLib.SelectOption(v2hmpg.getProjectTypeDrpDwn(), 11);// 55
		wLib.SelectOption(v2hmpg.getClientDrpDwn(), 55);

		v2hmpg.getProjectTextField().sendKeys(fLib.getPropertyKeyValue("projectname") + jLib.randomString());
		v2hmpg.getAddSubmitBtn().click();
		
		v2hmpg.getProjectBtn().click();
		v2hmpg.getlicencekeyBtnBtn().click();
		Thread.sleep(3000);
		wLib.SelectOption(v2lcnpg.getprojectdrpdwn(), 5);
		
		Thread.sleep(3000);
	}

}
