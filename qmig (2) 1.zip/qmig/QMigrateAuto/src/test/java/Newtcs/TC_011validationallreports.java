package Newtcs;

import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.V3.loginpage.v3homepage;
import com.genericsUtils.V3BaseClass;

public class TC_011validationallreports extends V3BaseClass {
@Test	
	public void tc3() throws Throwable {
		v3homepage v3hmpg2 = new v3homepage(driver);
		v3hmpg2.clickcodemigr().click();
		Thread.sleep(2000);
		v3hmpg2.clickvalidation().click();
		Thread.sleep(5000);;
		v3hmpg2.clickvalidationrunno().click();
		Thread.sleep(3000);
		wLib.SelectOption(v3hmpg2.clickvalidationrunno(), 2);
		Thread.sleep(5000);	
		v3hmpg2.clickvalidationconnectionname().click();
		wLib.SelectOption(v3hmpg2.clickvalidationconnectionname(), 2);
		Thread.sleep(5000);
		v3hmpg2.clickvalidationvalidationtargetnamename().click();
		wLib.SelectOption(v3hmpg2.clickvalidationvalidationtargetnamename(), 1);
		v3hmpg2.clickvalidationoperationname().click();
		wLib.SelectOption(v3hmpg2.clickvalidationoperationname(), 1);
		v3hmpg2.clickvvalidationschemaname().click();
		v3hmpg2.clickvvalidation1schemaname().click();
		Thread.sleep(5000);
		v3hmpg2.clickvalidationcheckdetails().click();
		v3hmpg2.clickvalidationexecutedetails().click();
		//wLib.rightClick(driver, v3hmpg2.clickvalidationexecutedetails());
	   // v3hmpg2.clickvalidationstatusrefreshbtn().click();
		Thread.sleep(20000);
		//wLib.scrollToWebElement(driver, v3hmpg2.clickvalidationreports());
		v3hmpg2.clickvalidationreports().click();
		wLib.scrollToWebElement(driver, v3hmpg2.clickvalidationreports());
		Thread.sleep(10000);
		v3hmpg2.clickvalidationreportsrunno().click();
		wLib.SelectOption(v3hmpg2.clickvalidationreportsrunno(), 2);
		Thread.sleep(5000);
		v3hmpg2.clickvalidationreportshrs().click();
		wLib.SelectOption(v3hmpg2.clickvalidationreportshrs(), 2);
		//v3hmpg2.clickvalidationblankspace().click();
		v3hmpg2.clickfooterpage().click();
		Thread.sleep(5000);

}
}
