package Newtcs;

import org.testng.annotations.Test;

import com.V3.loginpage.v3homepage;
import com.genericsUtils.V3BaseClass;

public class test extends V3BaseClass {
@Test
	public void tc3() throws Throwable {
		v3homepage v3hmpg2 = new v3homepage(driver);
		v3hmpg2.clickcodemigr().click();
		Thread.sleep(2000);
		v3hmpg2.clickvalidation().click();
		wLib.rightClick(driver, v3hmpg2.clickblnk());
		Thread.sleep(5000);
}
}