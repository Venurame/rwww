package Newtcs;

import org.testng.annotations.Test;

import com.V3.loginpage.v3homepage;
import com.genericsUtils.V3BaseClass;

public class TC_012validationallactivitylog extends V3BaseClass {
@Test
	public void tc3() throws Throwable {
		v3homepage v3hmpg2 = new v3homepage(driver);
		v3hmpg2.clickcodemigr().click();
		Thread.sleep(2000);
		v3hmpg2.clickvalidation().click();
		Thread.sleep(5000);;
	v3hmpg2.clickvalidationrunno().click();
		Thread.sleep(3000);
		wLib.SelectOption(v3hmpg2.clickvalidationrunno(), 2);
		Thread.sleep(5000);	
		v3hmpg2.clickvalidationconnectionname().click();
		wLib.SelectOption(v3hmpg2.clickvalidationconnectionname(), 2);
		Thread.sleep(5000);
		v3hmpg2.clickvalidationvalidationtargetnamename().click();
		wLib.SelectOption(v3hmpg2.clickvalidationvalidationtargetnamename(), 1);
		v3hmpg2.clickvalidationoperationname().click();
		wLib.SelectOption(v3hmpg2.clickvalidationoperationname(), 1);
		v3hmpg2.clickvvalidationschemaname().click();
		v3hmpg2.clickvvalidation1schemaname().click();
		Thread.sleep(5000);
		v3hmpg2.clickvalidationcheckdetails().click();
		v3hmpg2.clickvalidationexecutedetails().click();
		//v3hmpg2.clickvalidationstatusrefreshbtn().click();
		Thread.sleep(5000);
		//wLib.scrollToWebElement(driver, v3hmpg2.clickvalidationreports());
		v3hmpg2.clickvalidationreports().click();
		wLib.scrollToWebElement(driver, v3hmpg2.clickvalidationreports());
		Thread.sleep(10000);
		v3hmpg2.clickvalidationreportsrunno().click();
		wLib.SelectOption(v3hmpg2.clickvalidationreportsrunno(), 2);
		Thread.sleep(5000);
		//v3hmpg2.clickvalidationblankspace().click();
		Thread.sleep(5000);
		v3hmpg2.clickvalidationpageactivitylog().click();
		Thread.sleep(5000);
		v3hmpg2.clickvalidationpageactivitylblank().click();
		v3hmpg2.clickvalidationpageactivitylrunno().click();
		wLib.SelectOption(v3hmpg2.clickvalidationpageactivitylrunno(), 1);
		Thread.sleep(10000);
		//v3hmpg2.clickfooterpage().click();

}

}
